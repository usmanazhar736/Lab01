 #include <iostream>
using namespace std;

int findSumOfDigits(int* num) {
    int sum = 0;
    int temp = *num;
    while (temp != 0) {
        sum += temp % 10;
        temp /= 10;
    }
    return sum;
}

int main() {
    int num = 12345;
    cout << "Number: " << num << endl;
    int sum = findSumOfDigits(&num);
    cout << "Sum of digits: " << sum << endl;
    return 0;
}

