#include <iostream>
using namespace std;

void reverseString(char* str) {
    char* start = str;
    char* end = str;
    while (*end) {
        end++;
    }
    end--;

    while (start < end) {
        char temp = *start;
        *start = *end;
        *end = temp;
        start++;
        end--;
    }
}

int main() {
    char str[] = "Hello, World!";
    cout << "Before reversing: " << str << endl;
    reverseString(str);
    cout << "After reversing: " << str << endl;
    return 0;
}

