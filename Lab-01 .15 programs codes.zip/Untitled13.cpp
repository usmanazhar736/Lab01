#include <iostream>
using namespace std;

int findLargest(int* matrix, int rows, int cols) {
    int largest = *matrix;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (*(matrix + i * cols + j) > largest) {
                largest = *(matrix + i * cols + j);
            }
        }
    }
    return largest;
}

int main() {
    int matrix[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int rows = sizeof(matrix) / sizeof(matrix[0]);
    int cols = sizeof(matrix[0]) / sizeof(matrix[0][0]);
    int largest = findLargest(&matrix[0][0], rows, cols);
    cout << "Largest element in the matrix: " << largest << endl;
    return 0;
}

