#include <iostream>
using namespace std;

int findLength(char* str) {
    int length = 0;
    while (*str) {
        length++;
        str++;
    }
    return length;
}

int main() {
    char str[] = "Hello, World!";
    int length = findLength(str);
    cout << "Length of the string: " << length << endl;
    return 0;
}

