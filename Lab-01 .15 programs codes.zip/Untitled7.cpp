#include <iostream>
using namespace std;

int findFactorial(int* num) {
    int factorial = 1;
    for (int i = 1; i <= *num; i++) {
        factorial *= i;
    }
    return factorial;
}

int main() {
    int num = 5;
    cout << "Number: " << num << endl;
    int factorial = findFactorial(&num);
    cout << "Factorial: " << factorial << endl;
    return 0;
}

