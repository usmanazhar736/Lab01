#include <iostream>
using namespace std;

int findPower(int* base, int* exponent) {
    int result = 1;
    for (int i = 0; i < *exponent; i++) {
        result *= *base;
    }
    return result;
}

int main() {
    int base = 2, exponent = 5;
    cout << "Base: " << base << endl;
    cout << "Exponent: " << exponent << endl;
    int power = findPower(&base, &exponent);
    cout << "Result: " << power << endl;
    return 0;
}

