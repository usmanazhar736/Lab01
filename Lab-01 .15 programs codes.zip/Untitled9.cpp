#include <iostream>
using namespace std;

int findSum(int* num1, int* num2) {
    return *num1 + *num2;
}

int main() {
    int num1 = 5, num2 = 10;
    cout << "Number 1: " << num1 << endl;
    cout << "Number 2: " << num2 << endl;
    int sum = findSum(&num1, &num2);
    cout << "Sum: " << sum << endl;
    return 0;
}

