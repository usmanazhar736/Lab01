#include<iostream>
using namespace std;
class Node{
	private:
		int data;
		Node *next;
	public:
	  Node *top=NULL;
	  
  void push(int val){
  	Node * p= new Node();
  	p->data=val;
  	p->next=top;
  	top=p;

}

  void pop(){
  	if(top=NULL)
  	cout<<"Stack is underflow"<<endl;
  	else{
  		cout<<"The poped elements :"<<top->data;
  		top=top->next;
	  }


	}
  void display(){
  	Node *ptr;
  	if(top=NULL)
  	cout<<"Stack is empty"<<endl;
  	
  	else{
  		ptr=top;
  		cout<<"Stack elements :"<<endl;
  		while(ptr!=NULL){
  			cout<<ptr->data<<" ";
  			ptr=ptr->next;
		  }
	  }
  	
   cout<<endl;
	
}
	  	
};


int main(){
	Node a;
	int val , ch;
   cout<<"1) Push in stack"<<endl;
   cout<<"2) Pop from stack"<<endl;
   cout<<"3) Display stack"<<endl;
   cout<<"4) Exit"<<endl; 
   
  do{
  	cout<<"Enter a Choice :"<<endl;
  	cin>>ch;
  	 switch(ch){
  	 	case 1 :{
  	 		cout<<"Enter the value to be pushed :"<<endl;
  	 		cin>>val;
  	 		a.push(val);
			break;
		   }
		case 2 :{
			a.pop();
			break;
		}  
		case 3 :{
			a.display();
			break;
		} 
		case 4 :{
			cout<<"Exit"<<endl;
			break;
		}
		default :{
			cout<<"Invalid Choice :"<<endl;
			break;
		}
	   }
  } 
  while(ch!=4);
  return 0;
   
}
