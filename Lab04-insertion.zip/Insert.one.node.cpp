#include<iostream>
using namespace std;
class Node{
	private:
		int data;
		Node *next;
	public:
	 Node *head;
	 Node(){
	 	head==NULL;
	 }
	 void insertnode(int n){
	 
	 	if (head==NULL){
	 		//linklist is empty
	 		head=new Node();
	 		head->data=n;
	 		head->next=NULL;
		 }
		 
	 }
	 void display(){
	 	if(head==NULL){
	 		cout<<"THE LINKLISTS IS EMPTY";
		 }
		 else{
		 	cout<<head->data<<endl;
		 }
	 }	
};
int main (){
	Node n;
	n.insertnode(4);
	n.display();
	return 0;
}
