#include<iostream>
using namespace std;
class Node{
	private:
		int data;
		Node *next;
	public:
	    Node *head;
		Node(){
			head==NULL;
		}	
	void insaerttwonode(int n){
		if(head==NULL){
			//link list is empty
			head=new Node();
			head->data=n;
			head->next=NULL;
		}
		else{
			Node *p;
			p=new Node();
			p->data=n;
			p->next=NULL;
			head->next=p;
		}
	}
	void display(){
		Node* ptr;
		ptr=head;
		if(head==NULL){
			cout<<"Data in the linklist";
			return;
		}
		else{
			while(ptr!=NULL){
				cout<<ptr->data;
				ptr=ptr->next;
			}
		}
	}	
};
int main()
{
	Node n;
    n.insaerttwonode(1);
    n.insaerttwonode(2);
    n.insaerttwonode(20);
    n.display();
	return 0;
	
}
