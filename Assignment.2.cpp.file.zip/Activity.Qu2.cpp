#include <iostream>

using namespace std;

class Node {
public:
    int data;
    Node* next;
    Node(int val){
    	data=val;
		 next=NULL;
	} 
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() {
    	head=NULL;
	} 

    // Function to insert a node at the beginning
    void insertAtBeginning(int val) {
        Node* newNode = new Node(val);
        newNode->next = head;
        head = newNode;
    }

    // Function to insert a node at the end
    void insertAtEnd(int val) {
        Node* newNode = new Node(val);
        if (!head) {
            head = newNode;
        } else {
            Node* current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = newNode;
        }
    }

    // Function to display the linked list
    void display() {
        Node* current = head;
        while (current) {
            cout << current->data << " -> ";
            current = current->next;
        }
        cout << "nullptr" << endl;
    }
};

int main() {
    LinkedList sll;
    int choice, data;

    do {
        cout << "Which linked list you want:" << endl;
        cout << "1: Single" << endl;
        cout << "2: Double" << endl;
        cout << "3: Circular" << endl;
        cout << "4: Exit" << endl;
        cin >> choice;

        switch (choice) {
            case 1:
                int subChoice;
                do {
                    cout << "Which operation you want to perform:" << endl;
                    cout << "1: Insertion at beginning" << endl;
                    cout << "2: Insertion at end" << endl;
                    cout << "3: Display" << endl;
                    cout << "4: Exit" << endl;
                    cin >> subChoice;

                    switch (subChoice) {
                        case 1:
                            cout << "Enter data to insert at the beginning: ";
                            cin >> data;
                            sll.insertAtBeginning(data);
                            break;
                        case 2:
                            cout << "Enter data to insert at the end: ";
                            cin >> data;
                            sll.insertAtEnd(data);
                            break;
                        case 3:
                            cout << "Linked List: ";
                            sll.display();
                            break;
                        case 4:
                            break;
                        default:
                            cout << "Invalid option" << endl;
                    }
                } while (subChoice != 4);
                break;
            case 2:
                // Implement similar options for doubly linked list
                break;
            case 3:
                // Implement similar options for circular linked list
                break;
            case 4:
                cout << "Exiting program" << endl;
                break;
            default:
                cout << "Invalid option" << endl;
        }
    } while (choice != 4);

    return 0;
}

